<footer class="footer-section" data-mdb-offset>
        <div class="footer-content">
            <div class="footer-info">
                <h5>Connect with me</h5>
                <a href="https://www.linkedin.com" class="footer-link"><i class="fab fa-linkedin"></i> LinkedIn</a>
                <a href="https://github.com" class="footer-link"><i class="fab fa-github"></i> GitHub</a>
                <a href="https://twitter.com" class="footer-link"><i class="fab fa-twitter"></i> Twitter</a>
            </div>
            <div class="footer-info">
                <h5>Quick Links</h5>
                <a href="#projects" class="footer-link">Projects</a>
                <a href="#about" class="footer-link">About</a>
                <a href="#contact" class="footer-link">Contact</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 Your Name. All rights reserved.</p>
        </div>
    </footer>